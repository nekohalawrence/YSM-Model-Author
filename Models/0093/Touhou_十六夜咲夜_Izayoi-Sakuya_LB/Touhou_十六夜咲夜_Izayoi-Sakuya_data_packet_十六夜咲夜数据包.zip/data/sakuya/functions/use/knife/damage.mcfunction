damage @e[sort=nearest,distance=..0.01,limit=1] 4 minecraft:arrow by @s from @s
playsound item.trident.hit voice @a ~ ~1 ~ 0.5 1.3 0.05
particle block redstone_block ~ ~1 ~ 0.15 0.3 0.15 0.3 15
kill @s