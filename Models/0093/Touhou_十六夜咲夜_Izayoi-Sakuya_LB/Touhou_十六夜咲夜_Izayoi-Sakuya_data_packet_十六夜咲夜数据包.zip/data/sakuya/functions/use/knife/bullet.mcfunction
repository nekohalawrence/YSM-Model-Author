scoreboard players add @s sakuya.bullet_distance 1
tp @s ^ ^ ^0.9
execute positioned ~-0.5 ~-0.5 ~-0.5 at @e[dx=0,dy=0,dz=0,nbt={DeathTime:0s}] unless score @e[sort=nearest,distance=..0.01,limit=1] sakuya.id = @s sakuya.id run function sakuya:use/knife/damage
execute unless block ~ ~ ~ #sakuya:transparent run function sakuya:use/knife/broken
execute if score @s sakuya.bullet_distance matches 256.. run kill @s