execute as @e[type=!player,tag=!sakuya.knife,tag=sakuya.time_stop,distance=0.01..] at @s run function sakuya:use/watch/effects_stop/entity
execute as @e[type=!player,tag=sakuya.knife,tag=sakuya.time_stop,distance=0.01..] at @s run function sakuya:use/watch/effects_stop/knife
execute as @a[tag=sakuya.time_stop,distance=0.01..] at @s run function sakuya:use/watch/effects_stop/player
kill @e[tag=sakuya.player_position]

playsound block.bell.use voice @a ~ ~1 ~ 10000 2 1
scoreboard players set @s sakuya.cd1 5
tag @s remove sakuya.watch_user
