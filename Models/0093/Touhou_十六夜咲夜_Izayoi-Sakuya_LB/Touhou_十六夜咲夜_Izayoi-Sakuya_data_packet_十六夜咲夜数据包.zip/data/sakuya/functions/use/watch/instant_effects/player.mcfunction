attribute @s generic.movement_speed base set -10000000
attribute @s generic.attack_speed base set -10000000
attribute @s generic.attack_damage base set -10000000
effect give @s blindness infinite 0 true
effect give @s slow_falling infinite 9 true
effect give @s glowing infinite 0 true
summon minecraft:interaction ~ ~ ~ {Tags:["sakuya.player_position"],response:0b,height:3,width:3}
tp @e[tag=sakuya.player_position,distance=..0.01,sort=nearest,limit=1] ^ ^ ^ ~ ~
tag @s add sakuya.time_stop