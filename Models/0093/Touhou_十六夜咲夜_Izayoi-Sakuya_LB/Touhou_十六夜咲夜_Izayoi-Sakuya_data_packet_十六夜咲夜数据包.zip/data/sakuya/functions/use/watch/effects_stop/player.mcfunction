attribute @s generic.movement_speed base set 0.1
attribute @s generic.attack_speed base set 4
attribute @s generic.attack_damage base set 1
effect clear @s blindness
effect clear @s slow_falling
effect clear @s glowing
tag @s remove sakuya.time_stop