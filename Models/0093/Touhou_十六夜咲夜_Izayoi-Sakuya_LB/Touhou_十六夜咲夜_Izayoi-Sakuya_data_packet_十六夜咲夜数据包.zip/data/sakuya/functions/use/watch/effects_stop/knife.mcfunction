data merge entity @s {item:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:7260010}}}
tag @s remove sakuya.time_stop