playsound entity.item.break voice @a ~ ~ ~ 0.5 1.5 0.01
kill @s