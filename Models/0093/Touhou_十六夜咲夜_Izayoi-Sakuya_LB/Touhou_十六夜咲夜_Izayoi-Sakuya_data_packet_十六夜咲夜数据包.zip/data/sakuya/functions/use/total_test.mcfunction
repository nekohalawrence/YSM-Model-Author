#右键检测
execute if score @s sakuya.rightclick matches 1.. run function sakuya:use/click
#子弹检测
execute at @e[tag=sakuya.knife,tag=!sakuya.time_stop] if score @e[distance=..0.01,sort=nearest,limit=1] sakuya.id = @s sakuya.id as @e[distance=..0.01,sort=nearest,limit=1] run function sakuya:use/knife/bullet
execute if entity @s[tag=sakuya.watch_user] run function sakuya:use/watch/durative_test
#CD
execute if score @s sakuya.cd1 matches 1.. run scoreboard players remove @s sakuya.cd1 1