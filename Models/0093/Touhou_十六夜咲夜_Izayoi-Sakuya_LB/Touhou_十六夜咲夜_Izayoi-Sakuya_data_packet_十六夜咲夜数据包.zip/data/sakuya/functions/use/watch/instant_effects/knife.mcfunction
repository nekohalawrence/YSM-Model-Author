data merge entity @s {item:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:7260011}}}
tag @s add sakuya.time_stop