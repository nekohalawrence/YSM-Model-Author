#技能效果
summon item_display ~ ~1.3 ~ {Tags:["sakuya.knife"],item:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:7260010}}}
execute positioned ~ ~1.3 ~ run scoreboard players operation @e[tag=sakuya.knife,distance=..0.01,sort=nearest,limit=1] sakuya.id = @s sakuya.id
execute positioned ~ ~1.3 ~ run data merge entity @e[tag=sakuya.knife,distance=..0.01,sort=nearest,limit=1] {transformation:{right_rotation:[0.5f,0.5f,0.5f,0.5f],scale:[0.75f,0.75f,0.75f]}}
execute positioned ~ ~1.3 ~ run tp @e[tag=sakuya.knife,distance=..0.01,sort=nearest,limit=1] ^ ^ ^1 ~ ~

playsound item.trident.throw voice @a ~ ~1 ~ 0.3 1.5 0.01
playsound entity.snowball.throw voice @a ~ ~1 ~ 0.7 1.3 0.01