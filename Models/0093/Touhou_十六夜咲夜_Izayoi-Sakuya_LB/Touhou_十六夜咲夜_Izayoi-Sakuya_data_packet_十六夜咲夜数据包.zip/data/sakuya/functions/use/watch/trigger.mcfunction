tag @s add sakuya.watch_user
function touhou:characters/sakuya/operate/spellcard/sc1/set

playsound block.bell.use voice @a ~ ~1 ~ 10000 2 1
particle cloud ~ ~1 ~ 0.35 0.35 0.35 0.5 15 normal @a