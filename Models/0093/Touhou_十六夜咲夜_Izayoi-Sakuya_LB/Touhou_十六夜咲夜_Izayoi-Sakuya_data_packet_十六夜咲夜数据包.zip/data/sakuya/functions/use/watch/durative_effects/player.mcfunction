tp @s @e[tag=sakuya.player_position,distance=..0.01,sort=nearest,limit=1]
scoreboard players set @s sakuya.rightclick -1