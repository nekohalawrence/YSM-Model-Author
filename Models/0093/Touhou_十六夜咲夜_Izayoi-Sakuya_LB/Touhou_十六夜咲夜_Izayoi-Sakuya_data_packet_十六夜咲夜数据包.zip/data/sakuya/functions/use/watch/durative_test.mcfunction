execute as @e[type=!player,tag=!sakuya.knife,tag=!sakuya.time_stop,distance=0.01..] at @s run function sakuya:use/watch/instant_effects/entity
execute as @e[type=!player,tag=sakuya.knife,tag=!sakuya.time_stop,distance=0.01..] at @s run function sakuya:use/watch/instant_effects/knife
execute as @a[nbt=!{SelectedItem:{tag:{Tags:["sakuya.watch"]}}},tag=!sakuya.time_stop,distance=0.01..] at @s run function sakuya:use/watch/instant_effects/player
execute as @a[tag=sakuya.time_stop] at @s run function sakuya:use/watch/durative_effects/player