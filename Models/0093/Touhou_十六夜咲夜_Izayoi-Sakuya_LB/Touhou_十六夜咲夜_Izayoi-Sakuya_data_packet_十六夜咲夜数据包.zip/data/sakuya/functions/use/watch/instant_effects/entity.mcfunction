data modify entity @s Glowing set value 1b
data modify entity @s NoGravity set value 1b
data remove entity @s Motion
data modify entity @s NoAI set value 1b
tag @s add sakuya.time_stop