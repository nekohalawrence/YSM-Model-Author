execute if entity @s[nbt={SelectedItem:{tag:{Tags:["sakuya.knife"]}}}] run function sakuya:use/knife/shoot
execute if entity @s[tag=sakuya.watch_user,nbt={SelectedItem:{tag:{Tags:["sakuya.watch"]}}}] run function sakuya:use/watch/stop
execute if score @s[tag=!sakuya.watch_user,nbt={SelectedItem:{tag:{Tags:["sakuya.watch"]}}}] sakuya.cd1 matches 0 run function sakuya:use/watch/trigger
scoreboard players set @s sakuya.rightclick 0
