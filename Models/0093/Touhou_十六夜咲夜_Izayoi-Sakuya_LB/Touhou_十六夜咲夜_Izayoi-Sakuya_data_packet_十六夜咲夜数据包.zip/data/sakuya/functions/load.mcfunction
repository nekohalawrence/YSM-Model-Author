#加载提示
tellraw @a {"text":"咲夜数据包 加载成功","color":"green","italic":false}
tellraw @a [{"text":"输入","color":"gray","italic":false},{"text":"/function sakuya:get","color":"yellow","italic":false},{"text":" 获取物品","color":"gray","italic":false}]
#计分板创建
scoreboard objectives add sakuya.rightclick minecraft.used:minecraft.carrot_on_a_stick 
scoreboard objectives add sakuya.id dummy
scoreboard objectives add sakuya.cd0 dummy
scoreboard objectives add sakuya.cd1 dummy
scoreboard objectives add sakuya.cd2 dummy

scoreboard objectives add sakuya.bullet_distance dummy
scoreboard objectives add sakuya.bullet_time dummy
scoreboard objectives add sakuya.spellcard_time dummy

scoreboard objectives add sakuya.random dummy
scoreboard objectives add sakuya.random_x dummy
scoreboard objectives add sakuya.random_y dummy
scoreboard objectives add sakuya.random_rx dummy
scoreboard objectives add sakuya.random_ry dummy

scoreboard players set @a sakuya.cd1 0 
execute as @a at @s run function touhou:id