#唯一识别码
execute unless score @s id matches -2147483648.. run scoreboard players add #id sakuya.id 1
execute unless score @s id matches -2147483648.. run scoreboard players operation @s sakuya.id = #id sakuya.id